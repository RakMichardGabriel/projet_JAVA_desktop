-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le :  ven. 19 août 2022 à 09:17
-- Version du serveur :  5.7.21
-- Version de PHP :  5.6.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données :  `projetl3`
--

-- --------------------------------------------------------

--
-- Structure de la table `employe`
--

DROP TABLE IF EXISTS `employe`;
CREATE TABLE IF NOT EXISTS `employe` (
  `code` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(50) NOT NULL,
  `adresse` varchar(50) NOT NULL,
  `telephone` varchar(50) NOT NULL,
  `poste` varchar(50) NOT NULL,
  `contrat` varchar(50) NOT NULL,
  `salaire` int(50) DEFAULT NULL,
  PRIMARY KEY (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `employe`
--

INSERT INTO `employe` (`code`, `nom`, `adresse`, `telephone`, `poste`, `contrat`, `salaire`) VALUES
(3, 'RABE', 'LOT_VT_3_ANDRONDRA', '+261344415841', 'DIRECTEUR', 'CDD', 1000000),
(4, 'RABENJA', 'LOT_VT_3_ANDRONDRA', '+261344415841', 'AUTRES', 'INTERIME', 1000000),
(5, 'RAKOTOARIMANANA', 'LOT_VT_3_ANDRONDRA', '+261344415841', 'DIRECTEUR', 'ANNEE', 1000000),
(7, 'VOLA', 'Fianara', '0343456741', 'Autres', 'CDI', 30000),
(8, 'RAKOTO', 'LOT_VT_3_ANDRONDRA', '+261344415841', 'DIRECTEUR', 'INTERIME', 3000);

-- --------------------------------------------------------

--
-- Structure de la table `entreprise`
--

DROP TABLE IF EXISTS `entreprise`;
CREATE TABLE IF NOT EXISTS `entreprise` (
  `Numentre` int(11) NOT NULL AUTO_INCREMENT,
  `Design` varchar(255) NOT NULL,
  PRIMARY KEY (`Numentre`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `entreprise`
--

INSERT INTO `entreprise` (`Numentre`, `Design`) VALUES
(2, 'RA'),
(3, 'SARL'),
(4, 'SA'),
(5, 'Orange'),
(6, 'ORANGE');

-- --------------------------------------------------------

--
-- Structure de la table `travail`
--

DROP TABLE IF EXISTS `travail`;
CREATE TABLE IF NOT EXISTS `travail` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `numEmploye` int(11) NOT NULL,
  `numEntreprise` int(11) NOT NULL,
  `nbheures` int(11) NOT NULL,
  `tauxhoraire` int(11) NOT NULL,
  `dateembauche` date NOT NULL,
  PRIMARY KEY (`id`),
  KEY `numEmploye` (`numEmploye`),
  KEY `numEntreprise` (`numEntreprise`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Déchargement des données de la table `travail`
--

INSERT INTO `travail` (`id`, `numEmploye`, `numEntreprise`, `nbheures`, `tauxhoraire`, `dateembauche`) VALUES
(3, 3, 2, 1000000, 10000, '2022-10-02'),
(4, 4, 3, 4000, 10000, '2000-10-04'),
(7, 7, 5, 3, 3000, '2022-08-18'),
(8, 8, 6, 3, 3000, '2022-08-18');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `travail`
--
ALTER TABLE `travail`
  ADD CONSTRAINT `travail_ibfk_1` FOREIGN KEY (`numEmploye`) REFERENCES `employe` (`code`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `travail_ibfk_2` FOREIGN KEY (`numEntreprise`) REFERENCES `entreprise` (`Numentre`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
